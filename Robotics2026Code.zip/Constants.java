package frc.robot;

public final class Constants {
  public static final class DriveConstants {
    public static final int LEFT_LEADER_ID = 1;
    
    public static final int LEFT_FOLLOWER_ID = 2;
    
    public static final int RIGHT_LEADER_ID = 3;
    
    public static final int RIGHT_FOLLOWER_ID = 4;
    
    public static final int DRIVE_MOTOR_CURRENT_LIMIT = 60;
  }
  
  public static final class FuelConstants {
    public static final int FEEDER_MOTOR_ID = 6;
    
    public static final int INTAKE_LAUNCHER_MOTOR_ID = 5;
    
    public static final int FEEDER_MOTOR_CURRENT_LIMIT = 60;
    
    public static final int LAUNCHER_MOTOR_CURRENT_LIMIT = 60;
    
    public static final double INTAKING_FEEDER_VOLTAGE = -12.0D;
    
    public static final double INTAKING_INTAKE_VOLTAGE = 10.0D;
    
    public static final double LAUNCHING_FEEDER_VOLTAGE = 10.0D;
    
    public static final double LAUNCHING_LAUNCHER_VOLTAGE = 11.6D;
    
    public static final double SPIN_UP_FEEDER_VOLTAGE = 6.0D;
    
    public static final double SPIN_UP_SECONDS = 1.0D;
  }
  
  public static final class OperatorConstants {
    public static final int DRIVER_CONTROLLER_PORT = 0;
    
    public static final int OPERATOR_CONTROLLER_PORT = 1;
    
    public static final double DRIVE_SCALING = 0.7D;
    
    public static final double ROTATION_SCALING = 0.8D;
  }
}


/* Location:              C:\Users\lettj\Downloads\2026KitBotClasses.jar!\frc\robot\Constants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */